package core;

import model.user.User;

public class UserStats {
	private User User;
}
