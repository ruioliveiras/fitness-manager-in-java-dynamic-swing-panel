package core;

import java.awt.Event;

public class EventSimulation {
	
	private Event Event;
	
	
	
	
	
}
