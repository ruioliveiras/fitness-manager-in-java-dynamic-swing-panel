package model.activity;

public abstract class Collective extends Contest {

}
