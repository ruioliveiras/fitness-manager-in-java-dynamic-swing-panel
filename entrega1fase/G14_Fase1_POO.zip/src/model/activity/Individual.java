package model.activity;

public abstract class Individual extends Contest {

}
