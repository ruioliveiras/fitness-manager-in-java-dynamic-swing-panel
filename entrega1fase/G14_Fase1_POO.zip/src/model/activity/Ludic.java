package model.activity;


public abstract class Ludic extends Activity {

}
