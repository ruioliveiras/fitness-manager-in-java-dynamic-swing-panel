package model;

public interface ObjectKey {
	public Object getKey();
}
