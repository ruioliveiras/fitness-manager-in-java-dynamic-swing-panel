package model.user;


/**
 * Enumeration class Permissoes - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Permissoes
{
    Admin, User, Guest
}
