package model.user;


/**
 * Classe para enumercao de genero (sexo) dos utilizadores.
 * 
 * @author Andre Santos
 */
public enum Genero{
    Masculino, Feminino, Desconhecido
}
