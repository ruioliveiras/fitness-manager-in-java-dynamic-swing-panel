package model;

public interface Clonable {
	public Object clone();
}
