package model.events;

/**
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AddEventException extends Exception{
    
    public AddEventException(){
        super();
    }
    
    public AddEventException(String s) {
        super(s);
    }
    
}