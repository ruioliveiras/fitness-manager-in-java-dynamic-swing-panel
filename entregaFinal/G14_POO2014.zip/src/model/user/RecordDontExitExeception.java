package model.user;

public class RecordDontExitExeception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RecordDontExitExeception() {
		super();
	}
	public RecordDontExitExeception(String s) {
		super(s);
	}
}
