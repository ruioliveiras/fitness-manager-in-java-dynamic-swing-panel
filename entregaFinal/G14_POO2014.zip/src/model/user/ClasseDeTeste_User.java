package model.user;


/**
 * Classe para testar User.
 */
public class ClasseDeTeste_User {
    User u1 = new User();
    
}
