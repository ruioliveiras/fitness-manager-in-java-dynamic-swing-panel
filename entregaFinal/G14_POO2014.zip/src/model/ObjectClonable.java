package model;

public interface ObjectClonable {
	public Object clone();
}
